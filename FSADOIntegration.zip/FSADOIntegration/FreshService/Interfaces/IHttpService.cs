﻿using FreshService.Models;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace FreshService.Interfaces
{
    public interface IHttpService
    {
        Task<string> ExecuteApiAsync(ApiRequest request);

        Task<HttpContent> ExecuteApiForStreamAsync(ApiRequest request);
    }
}
