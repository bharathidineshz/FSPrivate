﻿using FreshService.Models.AzureDevops;
using FreshService.Models.FreshService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FreshService.Interfaces
{
    public interface ICommonService
    {
        string GetADOTagName(string FSItemCategory);
        string GetADOProjectName(string ADOOrganizationName, string FSItemCategory);
        Task<string> GetADOOrganizationName(string fsGroupName);
        Task SaveFSNotesToADO(List<Note> notes, string problemId, string ADOOrganizationName, string ADOProjectName, string workItemId);
        Task InsertAttachmentsTOFS(List<Attachments> attachments, string problemId);
        Task<List<WorkListItem>> InsertAttachmentsTOADO(List<Attachments> attachments, string ADOOrganizationName, string ADOProjectName);
        Task<List<Note>> GetAllFSNotes(string problemId);

        Task SaveADODiscussionToFS(List<Comment> commentsToAdd, string problemId, string WorkItemId, string ADOOrganizationName, string ADOProjectName);

        Task<List<Comment>> GetAllADODiscussion(string WorkItemId, string ADOOrganizationName, string ADOProjectName);
    }
}
