﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FreshService.Interfaces
{
    public interface IAuthenticationService
    {
        Task<string> AuthenticateWebhook(HttpRequest req, string FS_Or_ADO_Key);
    }
}
