using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using FreshService.Interfaces;
using FreshService.Models.AzureDevops;
using FreshService.Models;
using System.Net.Http;
using System.Text;
using System.Collections.Generic;
using FreshService.Models.FreshService;
using System.Linq;
using System.Dynamic;
using Microsoft.Extensions.Options;
using FreshService.Services;

namespace FreshService.Triggers
{
    public class FreshServiceProblemTrigger
    {
        private readonly IHttpService httpService;
        private readonly ITokenService tokenService;
        private readonly ICommonService commonService;
        private readonly IAuthenticationService authenticationService;
        private readonly ErrorService errorService;
        private readonly IOptions<LocalSettingsValues> _localSettingsValues;
        private readonly string FSApiKey;
        private string ADOProjectName;
        private string ADOTagName = string.Empty;
        private string ADOOrganizationName = string.Empty;

        public FreshServiceProblemTrigger(IHttpService httpService, ITokenService tokenService, IAuthenticationService authenticationService,
            IOptions<LocalSettingsValues> localSettingsValues, ICommonService commonService,
            ErrorService errorService)
        {
            this.httpService = httpService;
            this.tokenService = tokenService;
            this.authenticationService = authenticationService;
            this._localSettingsValues = localSettingsValues;
            this.FSApiKey = _localSettingsValues.Value.FSAPIKey;
            this.commonService = commonService;
            this.errorService = errorService;
        }

        [FunctionName("FreshServiceProblemUpsertTrigger")]
        public async Task<IActionResult> FreshServiceProblemUpsertTrigger([HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", Route = null)] HttpRequest req)
        {

            try
            {
                // Authorizing
                string authenticateMessage = await this.authenticationService.AuthenticateWebhook(req, "FreshService");
                if (authenticateMessage != "Authorized Client")
                {
                    this.errorService.CreateLogs(authenticateMessage, "");
                    return new BadRequestObjectResult(authenticateMessage);
                }

                //Getting Azure Access token
                string accessToken = await this.tokenService.GetAccessToken();
                int WorkItemId = 0;

                ApiRequest apiRequest = new ApiRequest();
                string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
                FreshServiceProblemWebhookResponse problemWebhookResponse = JsonConvert.DeserializeObject<FreshServiceProblemWebhookResponse>(requestBody);
                string problemId = problemWebhookResponse.FreshdeskWebhook.ProblemId.Split('-')[1].ToString();
                //Getting Problem Details 
                apiRequest = new ApiRequest
                {
                    Url = Constants.GetProblemByIdUrl.Replace("{problemId}", problemId),
                    HttpMethod = HttpMethod.Get,
                    AuthType = "Basic",
                    AuthValue = Convert.ToBase64String(Encoding.Default.GetBytes(FSApiKey))
                };
                string problemResponse = await this.httpService.ExecuteApiAsync(apiRequest);
                FreshServiceProblemResponse problemResponseDtls = JsonConvert.DeserializeObject<FreshServiceProblemResponse>(problemResponse);

                ADOOrganizationName = await this.commonService.GetADOOrganizationName(problemResponseDtls.Problem.CustomFields.ADOProject);
                ADOProjectName = this.commonService.GetADOProjectName(ADOOrganizationName, problemResponseDtls.Problem.ItemCategory.ToString());
                ADOTagName = this.commonService.GetADOTagName(problemResponseDtls.Problem.ItemCategory.ToString());
                if (ADOOrganizationName == null || ADOOrganizationName == string.Empty || ADOProjectName == null || ADOProjectName == string.Empty)
                {
                    if (ADOOrganizationName == null || ADOOrganizationName == string.Empty)
                    {
                        throw new Exception($"{problemResponseDtls.Problem.ItemCategory} Organization does not exists in Azure devops");
                    }
                    if (ADOProjectName == null || ADOProjectName == string.Empty)
                    {
                        throw new Exception($"{problemResponseDtls.Problem.CustomFields.ADOProject} Project does not exists in Azure devops");
                    }
                }

                //Getting workItem details of problem
                apiRequest = new ApiRequest
                {
                    Url = Constants.GetWorkItemByIdUrl.Replace("{organizationName}", ADOOrganizationName),
                    HttpMethod = HttpMethod.Post,
                    AuthType = "Bearer",
                    AuthValue = accessToken,
                    ContentType = "application/json",
                    Body = new
                    {
                        Query = Constants.GetWorkItemByProblemIdQuery.Replace("{problemId}", problemWebhookResponse.FreshdeskWebhook.ProblemId)
                    }
                };
                var workItemResponse = await this.httpService.ExecuteApiAsync(apiRequest);
                WorkItemResponse workItemResp = JsonConvert.DeserializeObject<WorkItemResponse>(workItemResponse);
                if ((workItemResp.workItems.Count == 0 && problemWebhookResponse.FreshdeskWebhook.ProblemStatus == "New") || workItemResp.workItems.Count > 0)
                {
                    //Mapping Problem info into Azure work item
                    List<WorkListItem> workListItem = new List<WorkListItem> { };
                    workListItem.Add(new WorkListItem { op = "add", path = "/fields/System.Title", from = null, value = problemResponseDtls.Problem.Subject });
                    workListItem.Add(new WorkListItem { op = "add", path = "/fields/Microsoft.VSTS.TCM.ReproSteps", from = null, value = problemResponseDtls.Problem.Description });
                    workListItem.Add(new WorkListItem { op = "add", path = "/fields/Microsoft.VSTS.Common.Priority", from = null, value = GetPriority(problemResponseDtls.Problem.CustomFields.AltigenPriority).ToString() });
                    workListItem.Add(new WorkListItem { op = "add", path = "/fields/Microsoft.VSTS.Common.Severity", from = null, value = GetSeverirty(problemResponseDtls.Problem.CustomFields.CustomerSeverity) });
                    workListItem.Add(new WorkListItem { op = "add", path = "/fields/Custom.SupportINC#", from = null, value = problemWebhookResponse.FreshdeskWebhook.ProblemId });
                    string[] UCProjects = { "MaxCS", "MaxUC", "CoreView UC", "Altigen IVR" };
                    if (problemResponseDtls.Problem.ItemCategory == "Altigen Athen Collaboration")
                    {
                        workListItem.Add(new WorkListItem { op = "add", path = "/fields/System.AssignedTo", from = null, value = Constants.ADOAltigenAssignedTo });
                    }
                    else if (UCProjects.Contains(problemResponseDtls.Problem.ItemCategory))
                    {
                        workListItem.Add(new WorkListItem { op = "add", path = "/fields/System.AssignedTo", from = null, value = Constants.ADOUCAssignedTo });
                    }
                    else
                    {
                        workListItem.Add(new WorkListItem { op = "add", path = "/fields/System.AssignedTo", from = null, value = Constants.ADOAssignedTo });
                    }


                    workListItem.Add(new WorkListItem { op = "add", path = "/fields/System.Tags", from = null, value = Constants.ADODefaultTagName + ";" + (ADOTagName != null ? ADOTagName : "") });
                    string[] status = new[] { "Open", "Limitation", "Resolved", "Additional Information Required" };
                    if (status.Contains(problemWebhookResponse.FreshdeskWebhook.ProblemStatus))
                    {
                        workListItem.Add(new WorkListItem { op = "add", path = "/fields/System.State", from = null, value = GetADOStatus(problemWebhookResponse.FreshdeskWebhook.ProblemStatus) });
                    }
                    if (workItemResp.workItems.Count == 0 && problemWebhookResponse.FreshdeskWebhook.ProblemStatus == "New")
                    {
                        List<WorkListItem> workListItemsAttachment = await this.commonService.InsertAttachmentsTOADO(problemResponseDtls.Problem.Attachments, ADOOrganizationName, ADOProjectName);
                        workListItem = workListItem.Concat(workListItemsAttachment).ToList();
                        apiRequest = new ApiRequest
                        {
                            Url = Constants.InsertWorkItemUrl.Replace("{organizationName}", ADOOrganizationName).Replace("{projectName}", ADOProjectName),
                            HttpMethod = HttpMethod.Post,
                            AuthType = "Bearer",
                            AuthValue = accessToken,
                            ContentType = "application/json-patch+json",
                            Body = workListItem
                        };
                        string workListItemResp = await this.httpService.ExecuteApiAsync(apiRequest);
                        WorkItem workItem = JsonConvert.DeserializeObject<WorkItem>(workListItemResp);
                        await this.InsertFSNotesToADODiscussion(problemId, workItem.id.ToString());
                        WorkItemId = workItem.id;
                    }
                    else if (workItemResp.workItems.Count > 0)
                    {
                        WorkItemId = workItemResp.workItems[0].id;
                        // Getting worklist attachment
                        apiRequest = new ApiRequest
                        {
                            Url = Constants.GetWorkListItemAttachments.Replace("{organizationName}", ADOOrganizationName).Replace("{project}", ADOProjectName).Replace("{workItemId}", workItemResp.workItems[0].id.ToString()),
                            HttpMethod = HttpMethod.Get,
                            AuthType = "Bearer",
                            AuthValue = accessToken
                        };
                        string attachmentResp = await this.httpService.ExecuteApiAsync(apiRequest);
                        WorkListItemAttachmentResponse workListItemDetails = JsonConvert.DeserializeObject<WorkListItemAttachmentResponse>(attachmentResp);
                        List<AttachmentRelations> workListItemAttachments = new List<AttachmentRelations>();
                        if (workListItemDetails.Relations != null)
                        {
                            workListItemAttachments = workListItemDetails.Relations.Where(k => k.Rel == "AttachedFile").ToList();
                        }

                        //Checking FS update and attachment count of problem and worklist item
                        if ((problemResponseDtls.Problem.CustomFields.Fsupdate != null && problemResponseDtls.Problem.CustomFields.Fsupdate)
                            || (workListItemAttachments.Count != problemResponseDtls.Problem.Attachments.Count))
                        {
                            List<Attachments> attachmentToAdd = problemResponseDtls.Problem.Attachments.ExceptBy(workListItemAttachments.Select(wl => wl.Attributes.name), t => t.Name).ToList();
                            List<WorkListItem> workListItemsAttachment = await this.commonService.InsertAttachmentsTOADO(attachmentToAdd, ADOOrganizationName, ADOProjectName);
                            workListItem = workListItem.Concat(workListItemsAttachment).ToList();
                            apiRequest = new ApiRequest
                            {
                                Url = Constants.UpdateWorkItemUrl.Replace("{organizationName}", ADOOrganizationName).Replace("{projectName}", ADOProjectName).Replace("{workItemId}", workItemResp.workItems[0].id.ToString()),
                                HttpMethod = HttpMethod.Patch,
                                AuthType = "Bearer",
                                AuthValue = accessToken,
                                ContentType = "application/json-patch+json",
                                Body = workListItem
                            };
                            var updateWorkitemRes = await this.httpService.ExecuteApiAsync(apiRequest);
                        }
                    }
                    await this.UpdateFSUpdateAndBugId(problemId, WorkItemId.ToString());
                }
                return new OkObjectResult("success");
            }
            catch (Exception ex)
            {
                this.errorService.CreateLogs(ex.Message, ex.StackTrace);
                return new BadRequestObjectResult(ex.Message);
            }
        }

        private int GetPriority(string priority)
        {
            try
            {
                if (priority.Contains("1")) return 1;
                else if (priority.Contains("2")) return 2;
                else if (priority.Contains("3")) return 3;
                else return 4;
            }
            catch (Exception ex)
            {
                this.errorService.CreateLogs(ex.Message, ex.StackTrace);
                throw ex;
            }

        }
        private string GetSeverirty(string value)
        {
            try
            {
                if (value.Contains("1")) return "1 - Critical";
                else if (value.Contains("2")) return "2 - High";
                else if (value.Contains("3")) return "3 - Medium";
                else return "4 - Low";
            }
            catch (Exception ex)
            {
                this.errorService.CreateLogs(ex.Message, ex.StackTrace);
                throw ex;
            }

        }



        [FunctionName("FreshServiceProblemNotesTrigger")]
        public async Task<IActionResult> FreshServiceProblemNotesTrigger(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", Route = null)] HttpRequest req)
        {
            try
            {
                string authenticateMessage = await this.authenticationService.AuthenticateWebhook(req, "FreshService");
                if (authenticateMessage != "Authorized Client")
                {
                    throw new Exception(authenticateMessage);
                }
                ApiRequest apiRequest = new ApiRequest();
                string url = string.Empty;
                string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
                FreshServiceNotesWebhook conversationWebhook = JsonConvert.DeserializeObject<FreshServiceNotesWebhook>(requestBody);
                string problemId = conversationWebhook.FreshdeskWebhook.ProblemId.Split("-")[1].ToString();
                apiRequest = new ApiRequest
                {
                    Url = Constants.GetProblemByIdUrl.Replace("{problemId}", problemId),
                    HttpMethod = HttpMethod.Get,
                    AuthType = "Basic",
                    AuthValue = Convert.ToBase64String(Encoding.Default.GetBytes(FSApiKey))
                };
                string problemResponse = await this.httpService.ExecuteApiAsync(apiRequest);
                FreshServiceProblemResponse problemRes = JsonConvert.DeserializeObject<FreshServiceProblemResponse>(problemResponse);
                ADOOrganizationName = await this.commonService.GetADOOrganizationName(problemRes.Problem.CustomFields.ADOProject);
                ADOProjectName = this.commonService.GetADOProjectName(ADOOrganizationName, problemRes.Problem.ItemCategory);
                if (ADOOrganizationName == null || ADOOrganizationName == string.Empty || ADOProjectName == null || ADOProjectName == string.Empty)
                {
                    if (ADOOrganizationName == null || ADOOrganizationName == string.Empty)
                    {
                        throw new Exception($"{problemRes.Problem.ItemCategory} Organization does not exists in Azure devops");
                    }
                    if (ADOProjectName == null || ADOProjectName == string.Empty)
                    {
                        throw new Exception($"{problemRes.Problem.CustomFields.ADOProject} Project does not exists in Azure devops");
                    }
                }
                string accessToken = await this.tokenService.GetAccessToken();
                apiRequest = new ApiRequest
                {
                    Url = Constants.GetWorkItemByIdUrl.Replace("{organizationName}", ADOOrganizationName),
                    HttpMethod = HttpMethod.Post,
                    AuthType = "Bearer",
                    AuthValue = accessToken,
                    ContentType = "application/json",
                    Body = new
                    {
                        Query = Constants.GetWorkItemByProblemIdQuery.Replace("{problemId}", conversationWebhook.FreshdeskWebhook.ProblemId)
                    }
                };
                var workItemResponse = await this.httpService.ExecuteApiAsync(apiRequest);
                WorkItemResponse workItemResp = JsonConvert.DeserializeObject<WorkItemResponse>(workItemResponse);
                if (workItemResp.workItems.Count == 0)
                {
                    return new OkObjectResult("success");
                }

                //Get discussions of problem
                List<Comment> allComments = new List<Comment>();
                allComments = await this.commonService.GetAllADODiscussion(workItemResp.workItems[0].id.ToString(), ADOOrganizationName, ADOProjectName);

                //Get Conversations of problem
                List<Note> allNotes = new List<Note>();
                allNotes = await this.commonService.GetAllFSNotes(problemId);
                if (allNotes.Count == allComments.Count)
                {
                    return new OkObjectResult("success");
                }

                List<Note> notesToAdd = allNotes.ExceptBy(allComments.Select(wl => wl.convertedCommentText), t => t.ConvertedNoteText).ToList();
                await this.commonService.SaveFSNotesToADO(notesToAdd, problemId, ADOOrganizationName, ADOProjectName, workItemResp.workItems[0].id.ToString());
                return new OkObjectResult("success");
            }
            catch (Exception ex)
            {
                this.errorService.CreateLogs(ex.Message, ex.StackTrace);
                return new BadRequestObjectResult(ex.Message);
            }
        }

        private string GetADOStatus(string FSStatus)
        {
            try
            {
                if (FSStatus == "Open") return "New";
                else if (FSStatus == "Limitation") return "Limitation";
                else if (FSStatus == "Additional Information Required") return "Pending";
                else return "Closed";
            }
            catch (Exception ex)
            {
                this.errorService.CreateLogs(ex.Message, ex.StackTrace);
                throw ex;
            }
        }

        private async Task InsertFSNotesToADODiscussion(string problemId, string workItemId)
        {
            try
            {
                ApiRequest apiRequest = new ApiRequest();
                //Get Conversations of problem
                List<Note> allNotes = new List<Note>();
                allNotes = await this.commonService.GetAllFSNotes(problemId);
                await this.commonService.SaveFSNotesToADO(allNotes, problemId, ADOOrganizationName, ADOProjectName, workItemId);
            }
            catch (Exception ex)
            {
                this.errorService.CreateLogs(ex.Message, ex.StackTrace);
                throw ex;
            }
        }
        private async Task UpdateFSUpdateAndBugId(string problemId, string workItemId)
        {
            try
            {
                dynamic updateProblemRequestBody = new ExpandoObject();
                updateProblemRequestBody.custom_fields = new ExpandoObject();
                updateProblemRequestBody.custom_fields.sync_fs_to_ado = false;
                updateProblemRequestBody.custom_fields.ado_bugid = $"BUG " + workItemId.ToString();// custom field name for bugId
                ApiRequest apiRequest = new ApiRequest
                {
                    Url = Constants.UpdateProblemUrl.Replace("{problemId}", problemId.ToString()),
                    ContentType = "application/json",
                    HttpMethod = HttpMethod.Put,
                    AuthType = "Basic",
                    AuthValue = Convert.ToBase64String(Encoding.Default.GetBytes(FSApiKey)),
                    Body = updateProblemRequestBody
                };
                var result = await this.httpService.ExecuteApiAsync(apiRequest);
            }
            catch (Exception ex)
            {
                this.errorService.CreateLogs(ex.Message, ex.StackTrace);
                throw ex;
            }
        }



    }
}
