using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using FreshService.Models;
using FreshService.Interfaces;
using System.Net.Http;
using System.Text;
using FreshService.Models.AzureDevops;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using FreshService.Models.FreshService;
using Microsoft.Extensions.Options;
using FreshService.Services;

namespace FreshService.Triggers
{
    public class WorkItemTriger
    {
        private readonly IHttpService httpService;
        private readonly ITokenService tokenService;
        private readonly IAuthenticationService authenticationService;
        private readonly IOptions<LocalSettingsValues> _localSettingsValues;
        private readonly ErrorService errorService;
        private readonly ICommonService commonService;
        private readonly string FSApiKey;
        private string ADOProjectName;
        private string ADOOrganizationName = string.Empty;
        public WorkItemTriger(IHttpService httpService, ITokenService tokenService, ErrorService errorService,
            IAuthenticationService authenticationService, IOptions<LocalSettingsValues> localSettingsValues, ICommonService commonService)
        {
            this.errorService = errorService;
            this._localSettingsValues = localSettingsValues;
            this.httpService = httpService;
            this.tokenService = tokenService;
            this.authenticationService = authenticationService;
            this.FSApiKey = this._localSettingsValues.Value.FSAPIKey;
            this.commonService = commonService;
        }

        [FunctionName("WorkItemTriger")]

        public async Task<IActionResult> Run([HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", Route = "WorkItemTriger")] HttpRequest req)
        {
            try
            {

                ApiRequest apiRequest = new ApiRequest();
                string authenticateMessage = await this.authenticationService.AuthenticateWebhook(req, "AzureDevops");
                if (authenticateMessage != "Authorized Client")
                {
                    throw new Exception(authenticateMessage);
                }
                string accessToken = await this.tokenService.GetAccessToken();
                string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
                WorkListItemRequest workListItemRequest = JsonConvert.DeserializeObject<WorkListItemRequest>(requestBody);
                if (workListItemRequest.Resource.revisedBy.Name.Contains("fsadoapp"))
                {
                    return new OkObjectResult("success");
                }

                string problemId = workListItemRequest.Resource.Revision.Fields.CustomJiraTicket.Split("-")[1];
                apiRequest = new ApiRequest
                {
                    Url = Constants.GetProblemByIdUrl.Replace("{problemId}", problemId),
                    HttpMethod = HttpMethod.Get,
                    AuthType = "Basic",
                    AuthValue = Convert.ToBase64String(Encoding.Default.GetBytes(FSApiKey))
                };
                string problemResponse = await this.httpService.ExecuteApiAsync(apiRequest);
                FreshServiceProblemResponse problemResponseDtls = JsonConvert.DeserializeObject<FreshServiceProblemResponse>(problemResponse);
                ADOOrganizationName = await this.commonService.GetADOOrganizationName(problemResponseDtls.Problem.CustomFields.ADOProject);
                ADOProjectName = workListItemRequest.Resource.Revision.Fields.project;
                if (workListItemRequest.Resource.Revision.Fields.CustomADUpdate || workListItemRequest.Resource.relations != null)
                {
                    string url = string.Empty;
                    dynamic updateRequestBody = new MultipartFormDataContent();

                    //check whether the attachedFile is in the workitem response

                    if (workListItemRequest.Resource.relations != null)
                    {
                        apiRequest = new ApiRequest
                        {
                            Url = Constants.GetWorkListItemAttachments.Replace("{organizationName}", ADOOrganizationName).Replace("{project}", ADOProjectName).Replace("{workItemId}", workListItemRequest.Resource.WorkItemId.ToString()),
                            HttpMethod = HttpMethod.Get,
                            AuthType = "Bearer",
                            AuthValue = accessToken
                        };
                        string attachmentResp = await this.httpService.ExecuteApiAsync(apiRequest);
                        WorkListItemAttachmentResponse workListItemDetails = JsonConvert.DeserializeObject<WorkListItemAttachmentResponse>(attachmentResp);
                        List<AttachmentRelations> workListItemAttachments = new List<AttachmentRelations>();
                        if (workListItemDetails.Relations != null)
                        {
                            workListItemAttachments = workListItemDetails.Relations.Where(k => k.Rel == "AttachedFile").ToList();
                        }

                        if ((workListItemAttachments.Count != problemResponseDtls.Problem.Attachments.Count))
                        {
                            if (workListItemRequest.Resource.relations.added.Count != 0)

                            {
                                foreach (var item in workListItemRequest.Resource.relations.added)
                                {
                                    ApiRequest apiRequestForFile = new ApiRequest
                                    {
                                        Url = item.url,
                                        AuthType = "Bearer",
                                        HttpMethod = HttpMethod.Get,
                                        AuthValue = await this.tokenService.GetAccessToken(),
                                    };

                                    HttpContent response = await this.httpService.ExecuteApiForStreamAsync(apiRequestForFile);

                                    Stream stream = response.ReadAsStreamAsync().Result;

                                    stream.Position = 0;

                                    MemoryStream memoryStream = new MemoryStream();

                                    stream.CopyTo(memoryStream);

                                    updateRequestBody.Add(new ByteArrayContent(memoryStream.ToArray()), "attachments[]", item.attributes.name);

                                }
                            }
                        }

                    }

                    if (workListItemRequest.Resource.Fields.SystemTitle != null)
                    {
                        updateRequestBody.Add(new StringContent(workListItemRequest.Resource.Fields.SystemTitle.NewValue), "subject");
                    }

                    if (workListItemRequest.Resource.Fields.MicrosoftVstsTcmReproSteps != null)
                    {
                        updateRequestBody.Add(new StringContent(workListItemRequest.Resource.Fields.MicrosoftVstsTcmReproSteps.NewValue), "description");
                    }

                    if (workListItemRequest.Resource.Fields.MicrosoftVstsCommonPriority != null)
                    {
                        if (workListItemRequest.Resource.Fields.MicrosoftVstsCommonPriority.NewValue != null)
                        {
                            updateRequestBody.Add(new StringContent(GetPriority(Convert.ToInt16(workListItemRequest.Resource.Fields.MicrosoftVstsCommonPriority.NewValue))), "custom_fields[altigen_priority]");

                        }
                    }
                    if (workListItemRequest.Resource.Fields.MicrosoftVstsCommonSeverity != null)
                    {
                        if (workListItemRequest.Resource.Fields.MicrosoftVstsCommonSeverity.NewValue != null)
                        {
                            updateRequestBody.Add(new StringContent(GetSeverirty(workListItemRequest.Resource.Fields.MicrosoftVstsCommonSeverity.NewValue)), "custom_fields[untitled]");
                        }
                    }
                    if (workListItemRequest.Resource.Fields.SystemState != null)
                    {
                        if (workListItemRequest.Resource.Fields.SystemState.NewValue != null)
                        {
                            updateRequestBody.Add(new StringContent((await GetFSStatus(workListItemRequest.Resource.Fields.SystemState.NewValue)).ToString()), "status");
                        }
                    }
                    if (workListItemRequest.Resource.Fields.SystemHistory != null)
                    {
                        dynamic discussionRequestBody = new ExpandoObject();
                        discussionRequestBody.body = workListItemRequest.Resource.Fields.SystemHistory.NewValue;
                        ApiRequest apiRequestForDiscussion = new ApiRequest
                        {
                            Url = Constants.InsertProblemNotes.Replace("{problemId}", problemId.ToString()),
                            ContentType = "application/json",
                            HttpMethod = HttpMethod.Post,
                            AuthType = "Basic",
                            AuthValue = Convert.ToBase64String(Encoding.Default.GetBytes(FSApiKey)),
                            Body = discussionRequestBody
                        };
                        this.httpService.ExecuteApiAsync(apiRequestForDiscussion);
                    }


                    ApiRequest apiRequestForUpdation = new ApiRequest
                    {

                        Url = Constants.UpdateProblemUrl.Replace("{problemId}", problemId.ToString()),

                        AuthType = "Basic",

                        HttpMethod = HttpMethod.Put,

                        MultipartFormDataContent = updateRequestBody,

                        AuthValue = Convert.ToBase64String(Encoding.Default.GetBytes(FSApiKey))

                    };

                    this.httpService.ExecuteApiAsync(apiRequestForUpdation);

                    url = string.Empty;

                    url = Constants.UpdateWorkItemUrl.Replace("{organizationName}", ADOOrganizationName).Replace("{projectName}", ADOProjectName).Replace("{workItemId}", workListItemRequest.Resource.WorkItemId

                        .ToString());

                    List<WorkListItem> workListItem = new List<WorkListItem> { };

                    workListItem.Add(new WorkListItem { op = "add", path = "/fields/Custom.SyncADOToFS", from = null, value = false });

                    apiRequest = new ApiRequest
                    {
                        Url = url,

                        HttpMethod = HttpMethod.Patch,

                        AuthType = "Bearer",

                        AuthValue = accessToken,

                        ContentType = "application/json-patch+json",

                        Body = workListItem

                    };

                    this.httpService.ExecuteApiAsync(apiRequest);
                }
                else
                {
                    if (workListItemRequest.Resource.Fields.SystemCount != null && workListItemRequest.Resource.Fields.SystemHistory != null)
                    {
                        List<Comment> allComments = new List<Comment>();
                        allComments = await this.commonService.GetAllADODiscussion(workListItemRequest.Resource.WorkItemId.ToString(), ADOOrganizationName, ADOProjectName);

                        //Get Conversations of problem
                        List<Note> allNotes = new List<Note>();
                        allNotes = await this.commonService.GetAllFSNotes(problemId);

                        if (allNotes.Count == allComments.Count)
                        {
                            return new OkObjectResult("success");
                        }
                        List<Comment> commentsToAdd = allComments.ExceptBy(allNotes.Select(wl => wl.ConvertedNoteText), t => t.convertedCommentText).ToList();

                        await this.commonService.SaveADODiscussionToFS(commentsToAdd, problemId, workListItemRequest.Resource.WorkItemId.ToString(), ADOOrganizationName, ADOProjectName);

                    }

                    else if (workListItemRequest.Resource.Fields.SystemCount == null && workListItemRequest.Resource.Fields.SystemHistory != null)
                    {
                        //get all the conversation a Problem 
                        //Get Conversations of problem
                        List<Note> allNotes = new List<Note>();
                        allNotes = await this.commonService.GetAllFSNotes(problemId);

                        //Get all comments from work Itm 

                        apiRequest = new ApiRequest
                        {
                            Url = Constants.AllCommentsByWorkListItemUrl.Replace("{organizationName}", ADOOrganizationName).Replace("{projectName}", ADOProjectName).Replace("{workListItemId}", workListItemRequest.Resource.WorkItemId.ToString()),
                            HttpMethod = HttpMethod.Get,
                            AuthType = "Bearer",
                            AuthValue = accessToken,
                            ContentType = "application/json-patch+json",
                            Body = ""

                        };
                        var WorkListItemComments = await this.httpService.ExecuteApiAsync(apiRequest);
                        CommentResponse commentsResponse = JsonConvert.DeserializeObject<CommentResponse>(WorkListItemComments);

                        if (allNotes.Count == commentsResponse.totalCount)
                        {
                            return new OkObjectResult("success");
                        }

                        //Comparer both list and chnage the left out 1 from FS  to 1 from ADO
                        var noteId = string.Empty;

                        dynamic noteUpdateRequest = new ExpandoObject();

                        ApiRequest apiRequestForDiscussionUpdate = new ApiRequest { };

                        foreach (var item in commentsResponse.comments)

                        {
                            var differItem = allNotes.Find(x => x.BodyText != item.text);

                            if (differItem != null)

                            {
                                //Find the id to be updated in the Problem

                                noteId = differItem.Id.ToString();

                                noteUpdateRequest.body = workListItemRequest.Resource.Fields.SystemHistory.NewValue;

                                //Update Url

                                apiRequestForDiscussionUpdate = new ApiRequest

                                {

                                    Url = Constants.UpdateProblemUrl.Replace("{problemId}", problemId).Replace("{noteId}", noteId.ToString()),

                                    ContentType = "application/json",

                                    HttpMethod = HttpMethod.Put,

                                    AuthType = "Basic",

                                    AuthValue = Convert.ToBase64String(Encoding.Default.GetBytes(FSApiKey)),

                                    Body = noteUpdateRequest

                                };

                                this.httpService.ExecuteApiAsync(apiRequestForDiscussionUpdate);

                                break;

                            }


                        }


                    }

                }

                return new OkObjectResult("success");

            }

            catch (Exception ex)
            {
                this.errorService.CreateLogs(ex.Message, ex.StackTrace);
                return new BadRequestObjectResult(ex.Message);
            }
        }
        private string GetPriority(int altigen_priority)
        {
            try
            {

                if (altigen_priority == 1) return "1 - All customers for a single product"; //1 - All customers for a single product  - 1 - All customers for single product impacted
                else if (altigen_priority == 2) return "2 - A Single customer is impacted"; //2 - A Single customer is impacted - 2 - A Single ustomer is impacted
                else if (altigen_priority == 3) return "3 - Single customer or User Issues";//3 - Single customer or User Issues - 3 - Single Company or User Issues
                else return "General request";
            }
            catch (Exception ex)
            {
                this.errorService.CreateLogs(ex.Message, ex.StackTrace);
                throw ex;
            }

        }
        private string GetSeverirty(string customer_severity)
        {
            try
            {
                if (customer_severity == "1 - Critical") return "1 - (Entire Company impacted)";
                else if (customer_severity == "2 - High") return "2 - (Some Users Impacted)";
                else if (customer_severity == "3 - Medium") return "3 - (Single user impact)";
                else return "General Request";
            }
            catch (Exception ex)
            {
                this.errorService.CreateLogs(ex.Message, ex.StackTrace);
                throw ex;
            }
        }
        private async Task<int> GetFSStatus(string adoStatus)
        {
            try
            {
                ApiRequest apiRequest = new ApiRequest
                {
                    Url = Constants.GetProblemStatusUrl,
                    HttpMethod = HttpMethod.Get,
                    AuthType = "Basic",
                    AuthValue = Convert.ToBase64String(Encoding.Default.GetBytes(FSApiKey))
                };
                string statusresp = await this.httpService.ExecuteApiAsync(apiRequest);
                FreshServiceStatus freshServiceStatus = JsonConvert.DeserializeObject<FreshServiceStatus>(statusresp);
                string fsStatus = string.Empty;
                if (adoStatus.ToLower() == "new") { fsStatus = "Open"; }
                else if (adoStatus.ToLower() == "active" || adoStatus.ToLower() == "in process" || adoStatus.ToLower() == "ready" || adoStatus.ToLower() == "released to qa")
                {
                    fsStatus = "In Progress";
                }
                else if (adoStatus.ToLower() == "limitation") { fsStatus = "Limitation"; }
                else if (adoStatus.ToLower() == "closed") { fsStatus = "Resolved"; }
                else if (adoStatus.ToLower() == "pending") { fsStatus = "Additional Information Required"; }
                Choice selectedStatus = freshServiceStatus.ProblemFields.Where(k => k.Name == "status").FirstOrDefault()?.Choices.Where(c => c.Value == fsStatus).FirstOrDefault();
                return Convert.ToInt32(selectedStatus?.Id);
            }
            catch (Exception ex)
            {
                this.errorService.CreateLogs(ex.Message, ex.StackTrace);
                throw ex;
            }

        }

    }
}
