﻿using Azure;
using FreshService.Triggers;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FreshService.Services
{
    public class ErrorService
    {
        private readonly ILogger<ErrorService> _logger;
        public ErrorService(ILogger<ErrorService> _logger)
        {
            this._logger = _logger;
        }
        public void CreateLogs(string errorMessage, string StackTrace)
        {
            try
            {
                var Log = new StringBuilder();
                if (StackTrace != "")
                {
                    Log.AppendLine($"StackTrace: {StackTrace}");
                }
                Log.AppendLine($"Message: {errorMessage}");

                _logger.LogError(Log.ToString());
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
    }
}
