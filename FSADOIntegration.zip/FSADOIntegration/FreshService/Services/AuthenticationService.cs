﻿using FreshService.Interfaces;
using FreshService.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using System;
using System.Buffers.Text;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FreshService.Services
{
    public class AuthenticationService : IAuthenticationService
    {
        private const string APIKEY = "Authorization";
        private readonly IOptions<LocalSettingsValues> _localSettingsValues;
        private readonly ErrorService errorService;
        public AuthenticationService(IOptions<LocalSettingsValues> localSettingsValues, ErrorService errorService)
        {
            _localSettingsValues = localSettingsValues;
            this.errorService = errorService;
        }
        public async Task<string> AuthenticateWebhook(HttpRequest req, string FS_Or_ADO_Key)
        {
            try
            {
                if (!req.Headers.TryGetValue(APIKEY, out
                        var extractedApiKey))
                {
                    return "Api Key was not provided ";
                }
                string authValue = string.Empty;
                if (FS_Or_ADO_Key == "FreshService")
                {
                    authValue = $"Basic {Convert.ToBase64String(Encoding.Default.GetBytes($"{this._localSettingsValues.Value.FSAPIKey}:X"))}";
                }
                else
                {
                    authValue = this._localSettingsValues.Value.ADOAuthValue;
                }
                if (!authValue.Equals(extractedApiKey))
                {
                    return "Unauthorized client";
                }
                return "Authorized Client";
            }
            catch (Exception ex)
            {
                this.errorService.CreateLogs(ex.Message, ex.StackTrace);
                throw ex;
            }
        }
    }
}
