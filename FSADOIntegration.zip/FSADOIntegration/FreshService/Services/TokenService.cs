﻿using Azure.Core;
using Azure.Identity;
using FreshService.Interfaces;
using FreshService.Models;
using FreshService.Triggers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace FreshService.Services
{
    public class TokenService : ITokenService
    {
        private readonly IOptions<LocalSettingsValues> _localSettingsValues;
        private readonly ErrorService errorService;

        public TokenService(IOptions<LocalSettingsValues> localSettingsValues, ErrorService errorService)
        {
            this._localSettingsValues = localSettingsValues;
            this.errorService = errorService;
        }
        public async Task<string> GetAccessToken()
        {
            try
            {
                string tenantId = this._localSettingsValues.Value.AzureTenantId;
                string clientId = this._localSettingsValues.Value.AzureClientId;
                string clientSecret = this._localSettingsValues.Value.AzureClientSecret;
                var credentials = new ClientSecretCredential(tenantId, clientId, clientSecret);
                string scope = this._localSettingsValues.Value.AzureScope;
                var accessToken = await credentials.GetTokenAsync(new TokenRequestContext(new[] { scope }));
                return accessToken.Token.ToString();
            }
            catch (Exception ex)
            {
                this.errorService.CreateLogs(ex.Message, ex.StackTrace);
                throw ex;
            }
        }
    }
}
