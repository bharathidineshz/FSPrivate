﻿using FreshService.Interfaces;
using FreshService.Models.FreshService;
using FreshService.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Options;
using Azure.Core;
using FreshService.Models.AzureDevops;
using HtmlAgilityPack;
using System.IO;
using System.Net.Http.Headers;
using System.Dynamic;

namespace FreshService.Services
{
    public class CommonService : ICommonService
    {
        private readonly IHttpService httpService;
        private readonly string FSApiKey;
        private readonly IOptions<LocalSettingsValues> _localSettingsValues;
        private readonly ITokenService tokenService;
        private readonly ErrorService errorService;
        public CommonService(IHttpService httpService, IOptions<LocalSettingsValues> localSettingsValues, ITokenService tokenService, ErrorService errorService)
        {
            this.httpService = httpService;
            this._localSettingsValues = localSettingsValues;
            this.FSApiKey = this._localSettingsValues.Value.FSAPIKey;
            this.tokenService = tokenService;
            this.errorService = errorService;
        }
        public string GetADOTagName(string FSItemCategory)
        {
            try
            {
                if (FSItemCategory == "CoreInteract")
                {
                    return "CI";
                }
                else if (FSItemCategory == "CoreEngage")
                {
                    return "CE";
                }
                else if (FSItemCategory == "CoreAttendant")
                {
                    return "CA";
                }
                else if (FSItemCategory == "WorkGroup Insights")
                {
                    return "WGI";
                }
                else
                {
                    return "";
                }
            }
            catch (Exception ex)
            {
                this.errorService.CreateLogs(ex.Message, ex.StackTrace);
                throw ex;
            }

        }

        public string GetADOProjectName(string ADOOrganizationName, string FSItemCategory)
        {
            try
            {
                string ADOProjectName = "";

                if (ADOOrganizationName == "CoreInteractTeam" && (FSItemCategory == "CoreInteract" || FSItemCategory == "CoreEngage" || FSItemCategory == "CoreAttendant" || FSItemCategory == "WorkGroup Insights"))
                {
                    ADOProjectName = "CoreInteract";
                }
                else if (ADOOrganizationName == "ServiceDeliveryCloudTeam" && FSItemCategory == "SD Cloud")
                {
                    ADOProjectName = "SDCloudPlatform";
                }
                else if (ADOOrganizationName == "CoreInteractTeam" && (FSItemCategory == "MaxCS" || FSItemCategory == "MaxUC" || FSItemCategory == "CoreView UC"))
                {
                    ADOProjectName = "CoreView UC";
                }
                else if (ADOOrganizationName == "CoreInteractTeam" || ADOOrganizationName == "ServiceDeliveryCloudTeam")
                {
                    ADOProjectName = FSItemCategory;
                }
                return ADOProjectName;
            }
            catch (Exception ex)
            {
                this.errorService.CreateLogs(ex.Message, ex.StackTrace);
                throw ex;
            }
        }

        public async Task<string> GetADOOrganizationName(string fsGroupName)
        {
            try
            {
                if (fsGroupName == "AzureDevOps - CI" || fsGroupName == "AzureDevOps - CS" || fsGroupName == "AzureDevOps - IVR" || fsGroupName == "AzureDevOps - UC")
                {
                    return "CoreInteractTeam";
                }
                else if (fsGroupName == "AzureDevOps - SD Cloud")
                {
                    return "ServiceDeliveryCloudTeam";
                }
                else
                {
                    return "";
                }
            }
            catch (Exception ex)
            {
                this.errorService.CreateLogs(ex.Message, ex.StackTrace);
                throw ex;
            }
        }

        private async Task<List<Note>> GetProblemNotesByPagination(int PageNo, string ProblemId)
        {
            try
            {
                //Get Conversations of problem
                ApiRequest apiRequest = new ApiRequest
                {
                    Url = Constants.GetProblemNotes.Replace("{problemId}", ProblemId).Replace("{pageNo}", PageNo.ToString()),
                    HttpMethod = HttpMethod.Get,
                    AuthType = "Basic",
                    AuthValue = Convert.ToBase64String(Encoding.Default.GetBytes(FSApiKey))
                };
                string conversationResp = await this.httpService.ExecuteApiAsync(apiRequest);
                FreshServiceNotesResponse problemNote = JsonConvert.DeserializeObject<FreshServiceNotesResponse>(conversationResp);
                return problemNote.Notes;
            }
            catch (Exception ex)
            {
                this.errorService.CreateLogs(ex.Message, ex.StackTrace);
                throw ex;
            }
        }

        public async Task<List<Note>> GetAllFSNotes(string problemId)
        {
            try
            {
                List<Note> allNotes = new List<Note>();
                List<Note> notes = new List<Note>();
                int PageNo = 1;
                DateTime Last24Hr = DateTime.UtcNow.AddDays(-1);
                do
                {
                    notes = await this.GetProblemNotesByPagination(PageNo, problemId);
                    allNotes = allNotes.Concat(notes.Where(k => k.CreatedAt.DateTime >= Last24Hr)).ToList();
                    PageNo += 1;
                } while (notes.Count > 0);

                foreach (Note note in allNotes)
                {
                    var htmlDocument = new HtmlDocument();
                    htmlDocument.LoadHtml(note.BodyText);
                    string plainText = HtmlEntity.DeEntitize(htmlDocument.DocumentNode.InnerText.Trim()).Trim();
                    note.ConvertedNoteText = plainText.Trim();
                }
                return allNotes;
            }
            catch (Exception ex)
            {
                this.errorService.CreateLogs(ex.Message, ex.StackTrace);
                throw ex;
            }
        }

        public async Task<List<Comment>> GetAllADODiscussion(string WorkItemId, string ADOOrganizationName, string ADOProjectName)
        {
            try
            {
                string accessToken = await this.tokenService.GetAccessToken();
                List<Comment> allComments = new List<Comment>();
                CommentResponse commentsResponse = new CommentResponse();
                string ADODiscussionUrl = Constants.AllCommentsByWorkListItemUrl.Replace("{organizationName}", ADOOrganizationName).Replace("{projectName}", ADOProjectName).Replace("{workListItemId}", WorkItemId);
                DateTime Last24Hr = DateTime.UtcNow.AddDays(-1);
                do
                {
                    commentsResponse = await this.GetADODiscussionByPagination(ADODiscussionUrl, accessToken);
                    allComments = allComments.Concat(commentsResponse.comments.Where(k => Convert.ToDateTime(k.createdDate) >= Last24Hr)).ToList();
                    if (commentsResponse.NextPage != null)
                    {
                        ADODiscussionUrl = commentsResponse?.NextPage.ToString();
                    }
                } while (commentsResponse.NextPage != null);

                foreach (Comment comment in allComments)
                {
                    var htmlDocument = new HtmlDocument();
                    htmlDocument.LoadHtml(comment.renderedText);
                    string plainText = HtmlEntity.DeEntitize(htmlDocument.DocumentNode.InnerText.Trim()).Trim();
                    comment.convertedCommentText = plainText.Trim();
                }
                return allComments;
            }
            catch (Exception ex)
            {
                this.errorService.CreateLogs(ex.Message, ex.StackTrace);
                throw ex;
            }
        }

        private async Task<CommentResponse> GetADODiscussionByPagination(string ADODiscussionUrl, string accessToken)
        {
            try
            {
                ApiRequest apiRequest = new ApiRequest
                {
                    Url = ADODiscussionUrl,
                    HttpMethod = HttpMethod.Get,
                    AuthType = "Bearer",
                    AuthValue = accessToken
                };
                var WorkListItemComments = await this.httpService.ExecuteApiAsync(apiRequest);
                CommentResponse commentsResponse = JsonConvert.DeserializeObject<CommentResponse>(WorkListItemComments);
                return commentsResponse;
            }
            catch (Exception ex)
            {
                this.errorService.CreateLogs(ex.Message, ex.StackTrace);
                throw ex;
            }
        }
        public async Task SaveFSNotesToADO(List<Note> notes, string problemId, string ADOOrganizationName, string ADOProjectName, string workItemId)
        {
            try
            {
                string accessToken = await this.tokenService.GetAccessToken();
                ApiRequest apiRequest = new ApiRequest();
                foreach (Note note in notes)
                {
                    {
                        FreshServiceNotesResponse currentNote = new FreshServiceNotesResponse();
                        if (note != null)
                        {
                            apiRequest = new ApiRequest
                            {
                                Url = Constants.GetProblemNoteById.Replace("{problemId}", problemId).Replace("{noteId}", note.Id.ToString()),
                                HttpMethod = HttpMethod.Get,
                                AuthType = "Basic",
                                AuthValue = Convert.ToBase64String(Encoding.Default.GetBytes(FSApiKey))
                            };

                            string noteResponse = await this.httpService.ExecuteApiAsync(apiRequest);
                            currentNote = JsonConvert.DeserializeObject<FreshServiceNotesResponse>(noteResponse);
                        }

                        apiRequest = new ApiRequest
                        {
                            Url = Constants.InsertWorkItemDiscussionUrl.Replace("{organizationName}", ADOOrganizationName).Replace("{projectName}", ADOProjectName).Replace("{workItemId}", workItemId),
                            HttpMethod = HttpMethod.Post,
                            AuthType = "Bearer",
                            AuthValue = accessToken,
                            ContentType = "application/json",
                            Body = new
                            {
                                text = note.ConvertedNoteText
                            }
                        };
                        this.httpService.ExecuteApiAsync(apiRequest);
                        List<Attachments> attachments = new List<Attachments>();
                        HtmlDocument doc = new HtmlDocument();
                        doc.LoadHtml(note.Body);
                        // Get the inner text of the div
                        HtmlNode divNode = doc.DocumentNode.SelectSingleNode("//div");
                        var imgNodes = doc.DocumentNode.SelectNodes("//img");
                        if (imgNodes != null)
                        {
                            foreach (var item in imgNodes)
                            {
                                string imageUrl = item.GetAttributeValue("src", "");
                                using (var client = new HttpClient())
                                {
                                    HttpResponseMessage responseMessage = await client.GetAsync(imageUrl);
                                    attachments.Add(new Attachments
                                    {
                                        Name = Path.GetFileName(responseMessage.RequestMessage.RequestUri.AbsolutePath.ToString()),
                                        AttachmentUrl = imageUrl
                                    });
                                }
                            }
                        }
                        if (currentNote.Note.Attachments.Count > 0)
                        {
                            attachments = attachments.Concat(currentNote.Note.Attachments).ToList();
                        }
                        if (attachments.Count > 0)
                        {
                            await this.InsertAttachmentsTOFS(attachments, problemId);
                            List<WorkListItem> workListItemsAttachment = await this.InsertAttachmentsTOADO(attachments, ADOOrganizationName, ADOProjectName);
                            apiRequest = new ApiRequest
                            {
                                Url = Constants.UpdateWorkItemUrl.Replace("{organizationName}", ADOOrganizationName).Replace("{projectName}", ADOProjectName).Replace("{workItemId}", workItemId),
                                HttpMethod = HttpMethod.Patch,
                                AuthType = "Bearer",
                                AuthValue = accessToken,
                                ContentType = "application/json-patch+json",
                                Body = workListItemsAttachment
                            };
                            var updateWorkitemRes = await this.httpService.ExecuteApiAsync(apiRequest);
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                this.errorService.CreateLogs(ex.Message, ex.StackTrace);
                throw ex;
            }

        }
        public async Task SaveADODiscussionToFS(List<Comment> commentsToAdd, string problemId, string WorkItemId, string ADOOrganizationName, string ADOProjectName)
        {
            try
            {
                string accessToken = await this.tokenService.GetAccessToken();
                string InsertProblemNotesUrl = Constants.InsertProblemNotes.Replace("{problemId}", problemId.ToString());
                string UpdateProblemUrl = Constants.UpdateProblemUrl.Replace("{problemId}", problemId.ToString());
                ApiRequest apiRequest = new ApiRequest();
                foreach (var comment in commentsToAdd)
                {
                    if (comment.text.Contains("img"))
                    {
                        //split the content from Html Doc

                        HtmlDocument doc = new HtmlDocument();
                        doc.LoadHtml(comment.text);

                        // Get the inner text of the div
                        HtmlNode divNode = doc.DocumentNode.SelectSingleNode("//div");
                        var imgNodes = doc.DocumentNode.SelectNodes("//img");

                        // Adding files in worklist item and problems
                        foreach (var item in imgNodes)
                        {
                            var imageUrl = item.GetAttributeValue("src", "");
                            var fileName = Path.GetFileName(imageUrl.ToString()).Split("fileName=")[1];
                            apiRequest = new ApiRequest
                            {
                                Url = imageUrl,
                                AuthType = "Bearer",
                                HttpMethod = HttpMethod.Get,
                                AuthValue = accessToken
                            };
                            HttpContent response = await this.httpService.ExecuteApiForStreamAsync(apiRequest);
                            Stream stream = response.ReadAsStreamAsync().Result;
                            stream.Position = 0;
                            MemoryStream memoryStream = new MemoryStream();
                            stream.CopyTo(memoryStream);
                            dynamic requestBodyForAttachment = new MultipartFormDataContent();
                            requestBodyForAttachment.Add(new ByteArrayContent(memoryStream.ToArray()), "attachments[]", fileName);
                            ByteArrayContent byteArrayContent = new ByteArrayContent(memoryStream.ToArray());
                            byteArrayContent.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/octet-stream");
                            string webServiceResponseContent = await response.ReadAsStringAsync();
                            apiRequest = new ApiRequest
                            {
                                Url = Constants.InsertWorkListItemAtatchmentUrl.Replace("{organizationName}", ADOOrganizationName).Replace("{project}", ADOProjectName).Replace("{fileName}", fileName),
                                HttpMethod = HttpMethod.Post,
                                AuthType = "Bearer",
                                AuthValue = accessToken,
                                ContentType = "application/octet-stream",
                                ByteArrayContent = byteArrayContent
                            };

                            string attachmentResp = await this.httpService.ExecuteApiAsync(apiRequest);
                            string attachmentUrl = JsonConvert.DeserializeObject<dynamic>(attachmentResp).url;
                            List<WorkListItem> workListItemAttchments = new List<WorkListItem> { };
                            workListItemAttchments.Add(new WorkListItem
                            {
                                op = "add",
                                path = "/relations/-",
                                value = new
                                {
                                    rel = "AttachedFile",
                                    url = attachmentUrl,
                                    attributes = new
                                    {
                                        name = fileName
                                    }
                                }

                            });
                            var workListItemAttchmentsurl = Constants.UpdateWorkItemUrl.Replace("{organizationName}", ADOOrganizationName).Replace("{projectName}", ADOProjectName).Replace("{workItemId}", WorkItemId);
                            apiRequest = new ApiRequest
                            {
                                Url = workListItemAttchmentsurl,
                                HttpMethod = HttpMethod.Patch,
                                AuthType = "Bearer",
                                AuthValue = accessToken,
                                ContentType = "application/json-patch+json",
                                Body = workListItemAttchments
                            };
                            this.httpService.ExecuteApiAsync(apiRequest);

                            apiRequest = new ApiRequest
                            {
                                Url = UpdateProblemUrl,
                                AuthType = "Basic",
                                HttpMethod = HttpMethod.Put,
                                MultipartFormDataContent = requestBodyForAttachment,
                                AuthValue = Convert.ToBase64String(Encoding.Default.GetBytes(FSApiKey))
                            };
                            this.httpService.ExecuteApiAsync(apiRequest);

                        }

                    }

                    dynamic discussionRequestBody = new ExpandoObject();
                    discussionRequestBody.body = comment.convertedCommentText;
                    apiRequest = new ApiRequest
                    {
                        Url = InsertProblemNotesUrl,
                        ContentType = "application/json",
                        AuthType = "Basic",
                        HttpMethod = HttpMethod.Post,
                        Body = discussionRequestBody,
                        AuthValue = Convert.ToBase64String(Encoding.Default.GetBytes(FSApiKey))
                    };
                    var res = await this.httpService.ExecuteApiAsync(apiRequest);
                }
            }
            catch (Exception ex)
            {
                this.errorService.CreateLogs(ex.Message, ex.StackTrace);
                throw ex;
            }
        }

        public async Task InsertAttachmentsTOFS(List<Attachments> attachments, string problemId)
        {
            try
            {
                ApiRequest apiRequest = new ApiRequest();
                MultipartFormDataContent problemRequestBody = new MultipartFormDataContent();

                foreach (var attachment in attachments)
                {
                    apiRequest = new ApiRequest
                    {
                        Url = attachment.AttachmentUrl,
                        HttpMethod = HttpMethod.Get,
                        AuthType = "Basic",
                        AuthValue = Convert.ToBase64String(Encoding.Default.GetBytes(FSApiKey))
                    };
                    HttpContent response = await this.httpService.ExecuteApiForStreamAsync(apiRequest);
                    Stream stream = response.ReadAsStreamAsync().Result;
                    stream.Position = 0;
                    MemoryStream memoryStream = new MemoryStream();
                    stream.CopyTo(memoryStream);
                    problemRequestBody.Add(new ByteArrayContent(memoryStream.ToArray()), "attachments[]", attachment.Name);
                }

                ApiRequest apiRequestForUpdation = new ApiRequest
                {
                    Url = Constants.UpdateProblemUrl.Replace("{problemId}", problemId),
                    AuthType = "Basic",
                    HttpMethod = HttpMethod.Put,
                    MultipartFormDataContent = problemRequestBody,
                    AuthValue = Convert.ToBase64String(Encoding.Default.GetBytes(FSApiKey))
                };

                this.httpService.ExecuteApiAsync(apiRequestForUpdation);
            }
            catch (Exception ex)
            {
                this.errorService.CreateLogs(ex.Message, ex.StackTrace);
                throw ex;
            }

        }

        public async Task<List<WorkListItem>> InsertAttachmentsTOADO(List<Attachments> attachments, string ADOOrganizationName, string ADOProjectName)
        {
            try
            {
                ApiRequest apiRequest = new ApiRequest();
                List<WorkListItem> workListItem = new List<WorkListItem>();
                string accessToken = await this.tokenService.GetAccessToken();
                foreach (var attachment in attachments)
                {
                    apiRequest = new ApiRequest
                    {
                        Url = attachment.AttachmentUrl,
                        HttpMethod = HttpMethod.Get,
                        AuthType = "Basic",
                        AuthValue = Convert.ToBase64String(Encoding.Default.GetBytes(FSApiKey))
                    };

                    HttpContent response = await this.httpService.ExecuteApiForStreamAsync(apiRequest);

                    Stream stream = response.ReadAsStreamAsync().Result;
                    MemoryStream memoryStream = new MemoryStream();
                    stream.CopyTo(memoryStream);


                    ByteArrayContent byteArrayContent = new ByteArrayContent(memoryStream.ToArray());
                    byteArrayContent.Headers.ContentType = new MediaTypeHeaderValue("application/octet-stream");

                    string webServiceResponseContent = await response.ReadAsStringAsync();

                    apiRequest = new ApiRequest
                    {
                        Url = Constants.InsertWorkListItemAtatchmentUrl.Replace("{organizationName}", ADOOrganizationName).Replace("{project}", ADOProjectName).Replace("{fileName}", attachment.Name),
                        HttpMethod = HttpMethod.Post,
                        AuthType = "Bearer",
                        AuthValue = accessToken,
                        ContentType = "application/octet-stream",
                        ByteArrayContent = byteArrayContent
                    };

                    string attachmentResp = await this.httpService.ExecuteApiAsync(apiRequest);
                    string attachmentUrl = JsonConvert.DeserializeObject<dynamic>(attachmentResp).url;
                    workListItem.Add(new WorkListItem
                    {
                        op = "add",
                        path = "/relations/-",
                        value = new
                        {
                            rel = "AttachedFile",
                            url = attachmentUrl,
                            attributes = new
                            {
                                name = attachment.Name
                            }
                        }

                    });
                }
                return workListItem;
            }
            catch (Exception ex)
            {
                this.errorService.CreateLogs(ex.Message, ex.StackTrace);
                throw ex;
            }
        }

    }
}


