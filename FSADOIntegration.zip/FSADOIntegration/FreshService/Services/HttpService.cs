﻿using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using FreshService.Interfaces;
using Newtonsoft.Json;
using FreshService.Models;
using Newtonsoft.Json.Serialization;

namespace FreshService.Services
{
    public class HttpService : IHttpService
    {
        private readonly ErrorService errorService;

        public HttpService(ErrorService errorService)
        {
            this.errorService = errorService;
        }
        public async Task<string> ExecuteApiAsync(ApiRequest req)
        {
            try
            {
                string result = string.Empty;

                var httpClient = new HttpClient();

                httpClient.DefaultRequestHeaders.Add("Authorization", $"{req.AuthType} {req.AuthValue}");

                var request = new HttpRequestMessage(req.HttpMethod, req.Url);
                if (req.Body != null)
                {
                    var json = JsonConvert.SerializeObject(req.Body, new JsonSerializerSettings { ContractResolver = new CamelCasePropertyNamesContractResolver() });
                    request.Content = new StringContent(json, Encoding.UTF8, req.ContentType);
                }
                else if (req.ByteArrayContent != null)
                {
                    request.Content = req.ByteArrayContent;

                }
                else if (req.MultipartFormDataContent != null)
                {
                    request.Content = req.MultipartFormDataContent;
                }
                var response = await httpClient.SendAsync(request);

                result = response.Content.ReadAsStringAsync().Result;
                if (!response.IsSuccessStatusCode)
                {
                    var error = new StringBuilder();
                    error.AppendLine($"Call to {req.Url} failed.");
                    error.AppendLine($"Reason: {response.ReasonPhrase}");
                    error.AppendLine($"Response Status Code: {response.StatusCode}");
                    throw new Exception(error.ToString());
                }
                return result;
            }
            catch (Exception ex)
            {
                this.errorService.CreateLogs(ex.Message, ex.StackTrace);
                throw ex;
            }

        }

        public async Task<HttpContent> ExecuteApiForStreamAsync(ApiRequest req)
        {
            try
            {
                HttpContent result;

                var httpClient = new HttpClient();

                httpClient.DefaultRequestHeaders.Add("Authorization", $"{req.AuthType} {req.AuthValue}");

                var request = new HttpRequestMessage(req.HttpMethod, req.Url);
                if (req.Body != null)
                {
                    var json = JsonConvert.SerializeObject(req.Body, new JsonSerializerSettings { ContractResolver = new CamelCasePropertyNamesContractResolver() });
                    request.Content = new StringContent(json, Encoding.UTF8, req.ContentType);
                }
                else if (req.ByteArrayContent != null)
                {
                    request.Content = req.ByteArrayContent;
                }

                var response = await httpClient.SendAsync(request);

                if (!response.IsSuccessStatusCode)
                {
                    var error = new StringBuilder();
                    error.AppendLine($"Call to {req.Url} failed.");
                    error.AppendLine($"Reason: {response.ReasonPhrase}");
                    error.AppendLine($"Response Status Code: {response.StatusCode}");
                    throw new Exception(error.ToString());
                }
                result = response.Content;
                return result;
            }
            catch (Exception ex)
            {
                this.errorService.CreateLogs(ex.Message, ex.StackTrace);
                throw ex;
            }

        }

    }
}
