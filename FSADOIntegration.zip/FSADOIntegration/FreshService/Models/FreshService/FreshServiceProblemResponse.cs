﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FreshService.Models.FreshService
{
    public partial class FreshServiceProblemResponse
    {
        [JsonProperty("problem")]
        public Problem Problem { get; set; }
    }

    public partial class Problem
    {
        [JsonProperty("planned_start_date")]
        public object PlannedStartDate { get; set; }

        [JsonProperty("planned_end_date")]
        public object PlannedEndDate { get; set; }

        [JsonProperty("planned_effort")]
        public object PlannedEffort { get; set; }

        [JsonProperty("id")]
        public long Id { get; set; }

        [JsonProperty("agent_id")]
        public object AgentId { get; set; }

        [JsonProperty("description")]
        public string Description { get; set; }

        [JsonProperty("description_text")]
        public string DescriptionText { get; set; }

        [JsonProperty("assets")]
        public List<object> Assets { get; set; }

        [JsonProperty("requester_id")]
        public long RequesterId { get; set; }

        [JsonProperty("subject")]
        public string Subject { get; set; }

        [JsonProperty("group_id")]
        public long? GroupId { get; set; }

        [JsonProperty("status")]
        public long Status { get; set; }

        [JsonProperty("due_by")]
        public DateTimeOffset DueBy { get; set; }

        [JsonProperty("known_error")]
        public bool KnownError { get; set; }

        [JsonProperty("department_id")]
        public object DepartmentId { get; set; }

        [JsonProperty("category")]
        public string Category { get; set; }

        [JsonProperty("sub_category")]
        public string SubCategory { get; set; }

        [JsonProperty("item_category")]
        public string ItemCategory { get; set; }

        [JsonProperty("created_at")]
        public DateTimeOffset CreatedAt { get; set; }

        [JsonProperty("updated_at")]
        public DateTimeOffset UpdatedAt { get; set; }


        [JsonProperty("attachments")]
        public List<Attachments> Attachments { get; set; }

        [JsonProperty("associated_change")]
        public object AssociatedChange { get; set; }

        [JsonProperty("custom_fields")]
        public CustomFields CustomFields { get; set; }
    }

    public partial class Attachments
    {
        [JsonProperty("id")]
        public long Id { get; set; }

        [JsonProperty("created_at")]
        public DateTimeOffset CreatedAt { get; set; }

        [JsonProperty("updated_at")]
        public DateTimeOffset UpdatedAt { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("attachment_url")]
        public string AttachmentUrl { get; set; }

        [JsonProperty("content_type")]
        public string ContentType { get; set; }

        [JsonProperty("size")]
        public long Size { get; set; }

        [JsonProperty("canonical_url")]
        public Uri CanonicalUrl { get; set; }
    }

    public partial class CustomFields
    {
        [JsonProperty("altigen_priority")]
        public string AltigenPriority { get; set; }

        [JsonProperty("untitled")]
        public string CustomerSeverity { get; set; }

        [JsonProperty("sync_fs_to_ado")]
        public bool Fsupdate { get; set; }

        [JsonProperty("ado_project")] // Used as Organization Azure
        public string ADOProject { get; set; }
    }
}
