﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace FreshService.Models.FreshService
{
    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse);
    public partial class FreshServiceNotesResponse
    {
        [JsonProperty("notes")]
        public List<Note> Notes { get; set; }

        [JsonProperty("note")]
        public Note Note { get; set; }
    }

    public partial class Note
    {
        [JsonProperty("id")]
        public long Id { get; set; }

        [JsonProperty("created_at")]
        public DateTimeOffset CreatedAt { get; set; }

        [JsonProperty("updated_at")]
        public DateTimeOffset UpdatedAt { get; set; }

        [JsonProperty("body")]
        public string Body { get; set; }

        [JsonProperty("body_text")]
        public string BodyText { get; set; }

        [JsonProperty("user_id")]
        public long UserId { get; set; }

        [JsonProperty("notify_emails")]
        public object NotifyEmails { get; set; }

        [JsonProperty("attachments")]
        public virtual List<Attachments> Attachments { get; set; }
        public string ConvertedNoteText { get; set; }
    }


}
