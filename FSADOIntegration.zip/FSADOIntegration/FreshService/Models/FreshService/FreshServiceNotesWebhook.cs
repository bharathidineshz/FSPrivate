﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FreshService.Models.FreshService
{
    public partial class FreshServiceNotesWebhook
    {
        [JsonProperty("freshdesk_webhook")]
        public virtual FreshdeskNoteWebhook FreshdeskWebhook { get; set; }
    }

    public partial class FreshdeskNoteWebhook
    {
        [JsonProperty("problem_id")]
        public virtual string ProblemId { get; set; }

        [JsonProperty("problem_subject")]
        public virtual string ProblemSubject { get; set; }

        [JsonProperty("problem_description")]
        public virtual string ProblemDescription { get; set; }

        [JsonProperty("problem_url")]
        public virtual Uri ProblemUrl { get; set; }

        [JsonProperty("associated_asset_ids")]
        public virtual string AssociatedAssetIds { get; set; }

        [JsonProperty("associated_asset_names")]
        public virtual string AssociatedAssetNames { get; set; }

        [JsonProperty("total_billable_hrs")]
        public virtual long TotalBillableHrs { get; set; }

        [JsonProperty("total_non_billable_hrs")]
        public virtual long TotalNonBillableHrs { get; set; }

        [JsonProperty("agent_id")]
        public virtual object AgentId { get; set; }

        [JsonProperty("event_performer_id")]
        public virtual long EventPerformerId { get; set; }

        [JsonProperty("event_performer_name")]
        public virtual string EventPerformerName { get; set; }

        [JsonProperty("event_performer_email")]
        public virtual string EventPerformerEmail { get; set; }

        [JsonProperty("problem_status")]
        public virtual string ProblemStatus { get; set; }

        [JsonProperty("problem_impact")]
        public virtual string ProblemImpact { get; set; }

        [JsonProperty("problem_priority")]
        public virtual string ProblemPriority { get; set; }

        [JsonProperty("problem_agent_name")]
        public virtual object ProblemAgentName { get; set; }

        [JsonProperty("problem_due_by_time")]
        public virtual string ProblemDueByTime { get; set; }

        [JsonProperty("planned_start_date")]
        public virtual string PlannedStartDate { get; set; }

        [JsonProperty("planned_end_date")]
        public virtual string PlannedEndDate { get; set; }

        [JsonProperty("planned_effort")]
        public virtual object PlannedEffort { get; set; }

        [JsonProperty("problem_department_name")]
        public virtual object ProblemDepartmentName { get; set; }

        [JsonProperty("problem_group")]
        public virtual object ProblemGroup { get; set; }

        [JsonProperty("problem_category")]
        public virtual string ProblemCategory { get; set; }

        [JsonProperty("problem_altigen_priority")]
        public virtual string ProblemAltigenpriority { get; set; }

        [JsonProperty("problem_untitled")]
        public virtual string ProblemCustomerseverity { get; set; }

        [JsonProperty("problem_sync_fs_to_ado")]
        public virtual object ProblemFsupdate { get; set; }

        [JsonProperty("problem_requester_name")]
        public virtual string ProblemRequesterName { get; set; }

        [JsonProperty("problem_requester_email")]
        public virtual string ProblemRequesterEmail { get; set; }

        [JsonProperty("problem_requester_location_name")]
        public virtual object ProblemRequesterLocationName { get; set; }

        [JsonProperty("requester_id")]
        public virtual long RequesterId { get; set; }

        [JsonProperty("helpdesk_name")]
        public virtual string HelpdeskName { get; set; }
    }
}
