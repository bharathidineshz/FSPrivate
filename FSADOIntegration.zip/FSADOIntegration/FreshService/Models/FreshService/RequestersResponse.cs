﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FreshService.Models.FreshService
{
    public class Requester
    {

        [JsonProperty("id")]
        public object id { get; set; }

        [JsonProperty("primary_email")]
        public string primary_email { get; set; }

    }

    public class RequestersResponse
    {
        [JsonProperty("requesters")]
        public List<Requester> requesters { get; set; }
    }


}
