﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FreshService.Models.FreshService
{
    public partial class FreshServiceProblemWebhookResponse
    {
        [JsonProperty("freshdesk_webhook")]
        public FreshdeskWebhook FreshdeskWebhook { get; set; }
    }

    public partial class FreshdeskWebhook
    {
        [JsonProperty("problem_id")]
        public string ProblemId { get; set; }

        [JsonProperty("problem_subject")]
        public string ProblemSubject { get; set; }

        [JsonProperty("problem_description")]
        public string ProblemDescription { get; set; }

        [JsonProperty("event_performer_id")]
        public long EventPerformerId { get; set; }

        [JsonProperty("event_performer_name")]
        public string EventPerformerName { get; set; }

        [JsonProperty("event_performer_email")]
        public string EventPerformerEmail { get; set; }

        [JsonProperty("problem_status")]
        public string ProblemStatus { get; set; }


        [JsonProperty("problem_category")]
        public string ProblemCategory { get; set; }

        [JsonProperty("problem_altigen_priority")]
        public string ProblemAltigenPriority { get; set; }

        [JsonProperty("problem_untitled")]
        public string ProblemCustomerSeverity { get; set; }

        [JsonProperty("problem_sync_fs_to_ado")]
        public object ProblemFsupdate { get; set; }

        [JsonProperty("problem_requester_name")]
        public string ProblemRequesterName { get; set; }

        [JsonProperty("problem_requester_email")]
        public string ProblemRequesterEmail { get; set; }

        [JsonProperty("requester_id")]
        public long RequesterId { get; set; }
    }
}
