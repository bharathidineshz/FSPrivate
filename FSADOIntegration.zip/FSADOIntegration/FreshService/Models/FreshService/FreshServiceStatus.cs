﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FreshService.Models.FreshService
{
    public partial class FreshServiceStatus
    {
        [JsonProperty("problem_fields")]
        public virtual List<ProblemField> ProblemFields { get; set; }
    }

    public partial class ProblemField
    {
        [JsonProperty("id")]
        public virtual long Id { get; set; }

        [JsonProperty("name")]
        public virtual string Name { get; set; }

        [JsonProperty("label")]
        public virtual string Label { get; set; }

        [JsonProperty("choices")]
        public virtual List<Choice> Choices { get; set; }

        [JsonProperty("nested_fields")]
        public virtual List<object> NestedFields { get; set; }

        [JsonProperty("workspace_id")]
        public virtual long WorkspaceId { get; set; }
    }

    public partial class Choice
    {
        [JsonProperty("id")]
        public virtual long Id { get; set; }

        [JsonProperty("value")]
        public virtual string Value { get; set; }
    }
}
