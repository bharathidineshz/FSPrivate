﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace FreshService.Models
{
    public class ApiRequest
    {
        public string Url { get; set; }

        public string ContentType { get; set; }

        public HttpMethod HttpMethod { get; set; }

        public string AuthType { get; set; }
        public string AuthValue { get; set; }

        public object Body { get; set; }

        public ByteArrayContent ByteArrayContent { get; set; }

        public MultipartFormDataContent MultipartFormDataContent { get; set; }

    }
}
