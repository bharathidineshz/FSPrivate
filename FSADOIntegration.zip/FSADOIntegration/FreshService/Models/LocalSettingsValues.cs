﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FreshService.Models
{
    public class LocalSettingsValues
    {
        public string FSAPIKey { get; init; }
        public string AzureClientId { get; init; }
        public string AzureClientSecret { get; init; }
        public string AzureTenantId { get; init; }
        public string AzureScope { get; init; }
        public string ADOAuthValue { get; init; }

    }
}
