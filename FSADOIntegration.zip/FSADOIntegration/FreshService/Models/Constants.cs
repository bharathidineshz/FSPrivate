﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FreshService.Models
{
    public class Constants
    {
        public const string UpdateProblemUrl = "https://altigen.freshservice.com//api/v2/problems/{problemId}";
        public const string GetProblemByIdUrl = "https://altigen.freshservice.com/api/v2/problems/{problemId}";
        public const string GetProblemStatusUrl = "https://altigen.freshservice.com//api/v2/problem_form_fields";
        public const string InsertProblemNotes = "https://altigen.freshservice.com//api/v2/problems/{problemId}/notes";
        public const string GetProblemNotes = "https://altigen.freshservice.com//api/v2/problems/{problemId}/notes?page={pageNo}&per_page=100";
        public const string GetProblemNoteById = "https://altigen.freshservice.com//api/v2/problems/{problemId}/notes/{noteId}";
        public const string UpdateNotesUrl = "https://altigen.freshservice.com//api/v2/problems/{problemId}/notes/{noteId}";
        public const string AllRequestersUrl = "https://altigen.freshservice.com//api/v2/requesters";

        public const string GetWorkItemByIdUrl = "https://dev.azure.com/{organizationName}/_apis/wit/wiql?api-version=5.1";
        public const string GetWorkItemByProblemIdQuery = "Select [System.Id], [System.Title], [System.State] From WorkItems where [Custom.SupportINC#]='{problemId}'";
        public const string InsertWorkItemUrl = "https://dev.azure.com/{organizationName}/{projectName}/_apis/wit/workitems/$Bug?api-version=6.1-preview.3";
        public const string UpdateWorkItemUrl = "https://dev.azure.com/{organizationName}/{projectName}/_apis/wit/workitems/{workItemId}?api-version=6.1-preview.3";
        public const string InsertWorkItemDiscussionUrl = "https://dev.azure.com/{organizationName}/{projectName}/_apis/wit/workitems/{workItemId}/comments?api-version=7.0-preview.3";
        public const string AllCommentsByWorkListItemUrl = "https://dev.azure.com/{organizationName}/{projectName}/_apis/wit/workItems/{workListItemId}/comments?$top=200&api-version=5.1-preview";
        public const string InsertWorkListItemAtatchmentUrl = "https://dev.azure.com/{organizationName}/{project}/_apis/wit/attachments?fileName={fileName}&api-version=7.0";
        public const string GetWorkListItemAttachments = "https://dev.azure.com/{organizationName}/{project}/_apis/wit/workitems/{workItemId}?$expand=relations&api-version=7.0-preview.3";
        public const string ADOAssignedTo = "kyang@altigen.com";
        public const string ADOAltigenAssignedTo = "dhivya.kumarasamy@altigen.com";
        public const string ADOUCAssignedTo = "bingyang.wu@altigen.com";
        public const string ADODefaultTagName = "FS to ADO";

        //public const string UpdateProblemUrl = "https://athen-servicedesk.freshservice.com/api/v2/problems/{problemId}";
        //public const string GetProblemByIdUrl = "https://athen-servicedesk.freshservice.com/api/v2/problems/{problemId}";
        //public const string GetWorkItemByIdUrl = "https://dev.azure.com/chanakya0611/_apis/wit/wiql?api-version=5.1";
        //public const string GetWorkItemByProblemIdQuery = "Select [System.Id], [System.Title], [System.State] From WorkItems where [Custom.SupportINC#]='{problemId}'";
        //public const string InsertWorkItemUrl = "https://dev.azure.com/chanakya0611/{projectName}/_apis/wit/workitems/$Bug?api-version=6.1-preview.3";
        //public const string UpdateWorkItemUrl = "https://dev.azure.com/chanakya0611/{projectName}/_apis/wit/workitems/{workItemId}?api-version=6.1-preview.3";
        //public const string InsertWorkItemDiscussionUrl = "https://dev.azure.com/chanakya0611/{projectName}/_apis/wit/workitems/{workItemId}/comments?api-version=7.0-preview.3";
        //public const string UpdateWorkItemDiscussionUrl = "https://dev.azure.com/chanakya0611/{projectName}/_apis/wit/workitems/{workItemId}/comments/{commentId}?api-version=7.0-preview.3";
        //public const string InsertProblemNotes = "https://athen-servicedesk.freshservice.com/api/v2/problems/{problemId}/notes";
        //public const string GetProblemNotes = "https://athen-servicedesk.freshservice.com/api/v2/problems/{problemId}/notes?page={pageNo}&per_page=100";
        //public const string GetProblemNoteById = "https://athen-servicedesk.freshservice.com/api/v2/problems/{problemId}/notes/{noteId}";
        //public const string UpdateNotesUrl = "https://athen-servicedesk.freshservice.com/api/v2/problems/{problemId}/notes/{noteId}";
        //public const string AllCommentsByWorkListItemUrl = "https://dev.azure.com/chanakya0611/{projectName}/_apis/wit/workItems/{workListItemId}/comments?api-version=5.1-preview";
        //public const string AllRequestersUrl = "https://athen-servicedesk.freshservice.com/api/v2/requesters";
        //public const string InsertWorkListItemAtatchmentUrl = "https://dev.azure.com/chanakya0611/{project}/_apis/wit/attachments?fileName={fileName}&api-version=7.0";
        //public const string GetWorkListItemAttachments = "https://dev.azure.com/chanakya0611/{project}/_apis/wit/workitems/{workItemId}?$expand=relations&api-version=7.0-preview.3";
        //public const string GetProblemStatusUrl = "https://athen-servicedesk.freshservice.com/api/v2/problem_form_fields";

    }
}
