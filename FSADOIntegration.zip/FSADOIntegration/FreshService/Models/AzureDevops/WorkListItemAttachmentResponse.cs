﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FreshService.Models.AzureDevops
{
    public partial class WorkListItemAttachmentResponse
    {
        [JsonProperty("id")]
        public long Id { get; set; }

        [JsonProperty("rev")]
        public long Rev { get; set; }

        [JsonProperty("relations")]
        public List<AttachmentRelations> Relations { get; set; }
    }

    public partial class AttachmentRelations
    {
        [JsonProperty("rel")]
        public string Rel { get; set; }

        [JsonProperty("url")]
        public Uri Url { get; set; }

        [JsonProperty("attributes")]
        public Attributes Attributes { get; set; }

    }

}
