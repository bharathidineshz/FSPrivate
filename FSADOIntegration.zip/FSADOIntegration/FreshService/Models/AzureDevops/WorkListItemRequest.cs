﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace FreshService.Models.AzureDevops
{

    public partial class WorkListItemRequest
    {
        [JsonProperty("resource")]
        public Resource Resource { get; set; }

    }

    public partial class Resource
    {
        [JsonProperty("fields")]
        public ResourceFields Fields { get; set; }

        [JsonProperty("revision")]
        public Revision Revision { get; set; }

        [JsonProperty("revisedBy")]
        public RevisedBy revisedBy { get; set; }

        [JsonProperty("workItemId")]
        public int WorkItemId { get; set; }

        [JsonProperty("relations")]
        public Relation relations { get; set; }
    }
    public class Added
    {
        [JsonProperty("rel")]
        public string rel { get; set; }

        [JsonProperty("url")]
        public string url { get; set; }

        [JsonProperty("attributes")]
        public Attributes attributes { get; set; }
    }

    public class Attributes
    {
        [JsonProperty("authorizedDate")]
        public DateTime authorizedDate { get; set; }

        [JsonProperty("id")]
        public int id { get; set; }

        [JsonProperty("resourceCreatedDate")]
        public DateTime resourceCreatedDate { get; set; }

        [JsonProperty("resourceModifiedDate")]
        public DateTime resourceModifiedDate { get; set; }

        [JsonProperty("revisedDate")]
        public DateTime revisedDate { get; set; }

        [JsonProperty("resourceSize")]
        public int resourceSize { get; set; }

        [JsonProperty("name")]
        public string name { get; set; }
    }
    public class Relation
    {
        [JsonProperty("added")]
        public List<Added> added { get; set; }
    }

    public partial class ResourceFields
    {

        [JsonProperty("System.State")]
        public UpdatedValue SystemState { get; set; }

        [JsonProperty("System.Title")]
        public UpdatedValue SystemTitle { get; set; }

        [JsonProperty("Microsoft.VSTS.Common.Priority")]
        public UpdatedValue MicrosoftVstsCommonPriority { get; set; }

        [JsonProperty("Microsoft.VSTS.Common.Severity")]
        public UpdatedValue MicrosoftVstsCommonSeverity { get; set; }

        [JsonProperty("Microsoft.VSTS.TCM.ReproSteps")]
        public UpdatedValue MicrosoftVstsTcmReproSteps { get; set; }

        [JsonProperty("System.History")]
        public UpdatedValue SystemHistory { get; set; }

        [JsonProperty("Custom.SyncADOToFS")]
        public UpdatedValue ADUpdate { get; set; }

        [JsonProperty("System.CommentCount")]
        public UpdatedValue SystemCount { get; set; }
        

    }
    public partial class UpdatedValue
    {
        [JsonProperty("oldValue")]
        public string OldValue { get; set; }

        [JsonProperty("newValue")]
        public string NewValue { get; set; }
    }

    public partial class Revision
    {
        [JsonProperty("fields")]
        public RevisionFields Fields { get; set; }

    }
    public partial class RevisedBy
    {
        [JsonProperty("name")]
        public string Name { get; set; }


        [JsonProperty("displayName")]
        public string DisplayName { get; set; }


        [JsonProperty("userName")]
        public string userName { get; set; }

    }

    public partial class RevisionFields
    {

        [JsonProperty("Custom.SupportINC#")]
        public string CustomJiraTicket { get; set; }

        [JsonProperty("System.TeamProject")]
        public string project { get; set; }

        [JsonProperty("Custom.SyncADOToFS")]
        public bool CustomADUpdate { get; set; }


        [JsonProperty("System.CreatedBy")]
        public string CreatedBy { get; set; }


    }

}
