﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FreshService.Models.AzureDevops
{
    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse);
    public class Avatar
    {
        public string href { get; set; }
    }

    public class Comment
    {
        public int workItemId { get; set; }
        public int id { get; set; }
        public int version { get; set; }
        public string text { get; set; }
        public CreatedBy createdBy { get; set; }
        public DateTime createdDate { get; set; }
        public ModifiedBy modifiedBy { get; set; }
        public DateTime modifiedDate { get; set; }
        public string format { get; set; }
        public string renderedText { get; set; }
        public string convertedCommentText { get; set; }
        public string url { get; set; }
    }

    public class CreatedBy
    {
        public string displayName { get; set; }
        public string url { get; set; }
        public Links _links { get; set; }
        public string id { get; set; }
        public string uniqueName { get; set; }
        public string imageUrl { get; set; }
        public string descriptor { get; set; }
    }

    public class Links
    {
        public Avatar avatar { get; set; }
    }

    public class ModifiedBy
    {
        public string displayName { get; set; }
        public string url { get; set; }
        public Links _links { get; set; }
        public string id { get; set; }
        public string uniqueName { get; set; }
        public string imageUrl { get; set; }
        public string descriptor { get; set; }
    }

    public class CommentResponse
    {
        public int totalCount { get; set; }
        public int count { get; set; }
        public Uri NextPage { get; set; }
        public List<Comment> comments { get; set; }
    }


}
