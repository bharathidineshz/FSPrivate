﻿using FreshService.Interfaces;
using FreshService.Services;
using FreshService.Triggers;
using Microsoft.ApplicationInsights.Channel;
using Microsoft.ApplicationInsights.Extensibility;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.ApplicationInsights;
using System;
using System.Threading.Channels;
using Microsoft.ApplicationInsights.DependencyCollector;
using Microsoft.ApplicationInsights.AspNetCore.Extensions;
using Microsoft.Extensions.Configuration;
using FreshService.Extensions;

[assembly: FunctionsStartup(typeof(FreshService.Startup))]

namespace FreshService
{
    public class Startup : FunctionsStartup
    {
        public override void Configure(IFunctionsHostBuilder builder)

        {
            var channel = new InMemoryChannel();

            builder.Services.AddScoped<IHttpService, HttpService>();
            builder.Services.AddScoped<ITokenService, TokenService>();
            builder.Services.AddScoped<IAuthenticationService, AuthenticationService>();
            builder.Services.AddScoped<ICommonService, CommonService>();
            builder.Services.AddScoped<FreshServiceProblemTrigger>();
            builder.Services.AddScoped<ErrorService>();

            var configuration = BuildConfiguration(builder.GetContext().ApplicationRootPath);
            builder.Services.AddAppConfiguration(configuration);

            builder.Services.Configure<TelemetryConfiguration>(config => config.TelemetryChannel = channel);
            builder.Services.AddLogging(a =>
            {
                a.AddApplicationInsights(
                    configureTelemetryConfiguration: (config) => config.ConnectionString = configuration["LocalSettingsValues:InstrumentationKey"],
                    configureApplicationInsightsLoggerOptions: (options) => { }
                );
                a.AddFilter<ApplicationInsightsLoggerProvider>(null, LogLevel.Trace);
                a.AddApplicationInsights();
            });

            builder.Services.AddApplicationInsightsTelemetry();
        }

        private IConfiguration BuildConfiguration(string applicationRootPath)
        {
            var config =
                new ConfigurationBuilder()
                    .SetBasePath(applicationRootPath)
                    .AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
                    .AddJsonFile("settings.json", optional: true, reloadOnChange: true)
                    .AddEnvironmentVariables()
                   .Build();

            return config;
        }


    }
}