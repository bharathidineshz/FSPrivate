﻿using FreshService.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FreshService.Extensions
{
    internal static class ConfigurationServiceCollectionExtensions
    {
        public static IServiceCollection AddAppConfiguration(this IServiceCollection services, IConfiguration config)
        {
            var test = config.GetSection(nameof(LocalSettingsValues));
            services.Configure<LocalSettingsValues>(config.GetSection(nameof(LocalSettingsValues)));
            return services;
        }

    }
}
